package com.cn.upscaler.ml

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.RectF
import ai.onnxruntime.*
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

interface SuperResolutionEngine { suspend fun upscale(source:Bitmap,tileSize:Int=192,overlap:Int=16,onProgress:(Int)->Unit={}):Bitmap; fun close() }

class RealEsrganEngine(private val context:Context):SuperResolutionEngine {
 private val env=OrtEnvironment.getEnvironment()
 private val session:OrtSession by lazy {
   val bytes=context.assets.open("models/realesr-general-x4v3.onnx").use{it.readBytes()}
   val opts=SessionOptions().apply{setOptimizationLevel(SessionOptions.OptLevel.ALL_OPT)}
   try { opts.addNnapi() } catch(_:Throwable) { }
   env.createSession(bytes,opts)
 }
 private val scale=4
 override suspend fun upscale(source:Bitmap,tileSize:Int,overlap:Int,onProgress:(Int)->Unit):Bitmap {
   if(tileSize<=overlap*2) throw IllegalArgumentException("Tile size must be greater than twice overlap")
   val outW=source.width*scale; val outH=source.height*scale
   val out=Bitmap.createBitmap(outW,outH,Bitmap.Config.ARGB_8888)
   val accum=FloatArray(outW*outH*3); val weights=FloatArray(outW*outH)
   val step=tileSize-overlap*2
   val xs=(0 until source.width step step).toList(); val ys=(0 until source.height step step).toList(); val total=xs.size*ys.size; var done=0
   for(y0 in ys) for(x0 in xs){
     val x1=min(source.width,x0+tileSize); val y1=min(source.height,y0+tileSize)
     val tile=Bitmap.createBitmap(source,x0,y0,x1-x0,y1-y0)
     val sr=infer(tile)
     val dx=x0*scale; val dy=y0*scale
     blend(sr,accum,weights,dx,dy,x0,y0,source.width,source.height,overlap*scale)
     tile.recycle(); sr.recycle(); done++; onProgress(done*100/total)
   }
   for(i in weights.indices){val w=weights[i]; if(w>0){accum[i*3]=(accum[i*3]/w).coerceIn(0f,255f);accum[i*3+1]=(accum[i*3+1]/w).coerceIn(0f,255f);accum[i*3+2]=(accum[i*3+2]/w).coerceIn(0f,255f)}}
   var p=0; val pixels=IntArray(outW*outH); for(i in pixels.indices){pixels[i]=(0xFF shl 24) or (accum[p++].toInt() shl 16) or (accum[p++].toInt() shl 8) or accum[p++].toInt()}
   out.setPixels(pixels,0,outW,0,0,outW,outH); return out
 }
 private fun infer(b:Bitmap):Bitmap{
   val w=b.width; val h=b.height; val data=FloatArray(1*3*w*h); val px=IntArray(w*h); b.getPixels(px,0,w,0,0,w,h); var i=0
   for(y in 0 until h) for(x in 0 until w){val c=px[y*w+x]; data[i]=((c shr 16) and 255)/255f; data[w*h+i]=((c shr 8) and 255)/255f; data[2*w*h+i]=(c and 255)/255f; i++}
   val input=session.inputNames.iterator().next(); val tensor=OnnxTensor.createTensor(env,FloatBuffer.wrap(data),longArrayOf(1,3,h.toLong(),w.toLong()))
   tensor.use { val result=session.run(mapOf(input to it)); result.use { val value=it[0].value; val arr=value as Array<*>; val c=arr[0] as Array<*>; val outC=c.size; val outH=(c[0] as Array<*>).size; val outW=((c[0] as Array<*>)[0] as FloatArray).size; val o=Bitmap.createBitmap(outW,outH,Bitmap.Config.ARGB_8888); val pix=IntArray(outW*outH); for(yy in 0 until outH) for(xx in 0 until outW){val r=((c[0] as Array<*>)[yy] as FloatArray)[xx].coerceIn(0f,1f); val g=((c[1] as Array<*>)[yy] as FloatArray)[xx].coerceIn(0f,1f); val bl=((c[min(2,outC-1)] as Array<*>)[yy] as FloatArray)[xx].coerceIn(0f,1f); pix[yy*outW+xx]=(255 shl 24) or ((r*255).toInt() shl 16) or ((g*255).toInt() shl 8) or (bl*255).toInt() }; o.setPixels(pix,0,outW,0,0,outW,outH); return o } }
 }
 private fun blend(tile:Bitmap,acc:FloatArray,weights:FloatArray,dx:Int,dy:Int,x0:Int,y0:Int,srcW:Int,srcH:Int,fade:Int){ val tw=tile.width;val th=tile.height;val p=IntArray(tw*th);tile.getPixels(p,0,tw,0,0,tw,th);for(y in 0 until th){for(x in 0 until tw){val ox=dx+x;val oy=dy+y;if(ox>=acc.size)continue;val idx=oy*(srcW*scale)+ox;if(idx<0||idx>=weights.size)continue;val edge=min(min(x,tw-1-x),min(y,th-1-y));val w=if(fade>0)min(1f,edge.toFloat()/fade) else 1f;val c=p[y*tw+x];acc[idx*3]+=((c shr 16) and 255)*w;acc[idx*3+1]+=((c shr 8) and 255)*w;acc[idx*3+2]+=(c and 255)*w;weights[idx]+=w}}}
 override fun close(){session.close()}
}
