package com.cn.upscaler.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.provider.MediaStore
import com.cn.upscaler.domain.*
import com.cn.upscaler.ml.RealEsrganEngine
import com.cn.upscaler.util.ImageUtils
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

class ImageProcessor(private val context:Context){
 suspend fun process(uri:android.net.Uri,target:Target,format:OutputFormat,onProgress:(Int)->Unit={}):String{
   val info=ImageUtils.inspect(context,uri); val src=ImageUtils.decode(context,uri)
   val ai=RealEsrganEngine(context)
   try{
     onProgress(5); val x4=ai.upscale(src,onProgress={p->onProgress(10+p*70/100)})
     val r=ResolutionCalculator.calculate(info.width,info.height,target)
     val final=if(x4.width==r.width&&x4.height==r.height)x4 else Bitmap.createScaledBitmap(x4,r.width,r.height,true)
     if(final!==x4)x4.recycle(); src.recycle(); onProgress(90)
     val name=FileNameGenerator.generate(queryName(uri),target,format,0); val resolver=context.contentResolver
     val values=ContentValues().apply{put(MediaStore.Images.Media.DISPLAY_NAME,name);put(MediaStore.Images.Media.MIME_TYPE,format.mime);put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/CN Upscaler/${target.label.substringBefore(' ')}");put(MediaStore.Images.Media.IS_PENDING,1);put(MediaStore.Images.Media.DESCRIPTION,"CN Upscaler | AI Super Resolution | ${info.width}x${info.height} -> ${r.width}x${r.height}")}
     val out=resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: error("Unable to create gallery item")
     try{resolver.openOutputStream(out)?.use{os->val q=95; when(format){OutputFormat.JPEG->final.compress(Bitmap.CompressFormat.JPEG,q,os);OutputFormat.PNG->final.compress(Bitmap.CompressFormat.PNG,100,os);OutputFormat.WEBP->final.compress(Bitmap.CompressFormat.WEBP_LOSSY,q,os)} }; values.clear();values.put(MediaStore.Images.Media.IS_PENDING,0);resolver.update(out,values,null,null);final.recycle();onProgress(100);return out.toString()}catch(t:Throwable){resolver.delete(out,null,null);throw t}
   } finally { ai.close() }
 }
 private fun queryName(uri:android.net.Uri):String{ return context.contentResolver.query(uri,arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),null,null,null)?.use{if(it.moveToFirst())it.getString(0) else "image"}?:"image" }
}
