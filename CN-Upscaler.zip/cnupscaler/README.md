# CN Upscaler

Offline Android image upscaler with 2K, 4K and 8K target modes and multi-image selection.

## GitHub build
1. Upload the contents of this ZIP to the root of a GitHub repository.
2. Open **Actions** → **Build CN Upscaler APK**.
3. Choose **Run workflow** (or push to `main`).
4. Download the `CN-Upscaler-debug-apk` artifact.

## Important
This starter release performs high-quality Android bitmap resampling. It is **not an AI super-resolution model**. A true AI/ML super-resolution engine requires a compatible, legally redistributable model file (for example ONNX/TFLite/NCNN) and its runtime. No fake AI claim is made here.

The app processes selected images locally and saves JPEG outputs under `Pictures/CN Upscaler` on Android 10+.
