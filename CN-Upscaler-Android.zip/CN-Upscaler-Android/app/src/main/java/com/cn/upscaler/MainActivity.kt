package com.cn.upscaler

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.*
import com.cn.upscaler.domain.*
import com.cn.upscaler.ui.AppViewModel

class MainActivity:ComponentActivity(){private val vm by viewModels<AppViewModel>();override fun onCreate(b:Bundle?){super.onCreate(b);setContent{MaterialTheme{App(vm)}}}}
@Composable fun App(vm:AppViewModel){val nav=rememberNavController();NavHost(nav,"home"){composable("home"){Home(nav,vm)};composable("settings"){Settings(nav,vm)};composable("history"){History(nav,vm)};composable("about"){About(nav)}}}
@Composable fun Home(nav:NavHostController,vm:AppViewModel){val jobs by vm.jobs.collectAsStateWithLifecycle();val picker=rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(50)){vm.addUris(it)};Scaffold(topBar={TopAppBar(title={Text("CN Upscaler")},actions={TextButton({nav.navigate("settings")}){Text("Settings")}})}){p->Column(Modifier.padding(p).padding(16.dp).fillMaxSize(),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Offline AI Image Super Resolution",style=MaterialTheme.typography.titleMedium);Button({picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))},Modifier.fillMaxWidth()){Text("+ Add Images")};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton({nav.navigate("history")}){Text("History")};OutlinedButton({nav.navigate("about")}){Text("About")}};Text("Target: ${vm.target.label} • ${vm.format.label}");if(jobs.isNotEmpty()){Text("Queue (${jobs.size})",style=MaterialTheme.typography.titleLarge);LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){items(jobs,key={it.id}){j->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(j.name);Text(j.status.name);if(j.error!=null)Text(j.error!!)}}}};Button({vm.process()},Modifier.fillMaxWidth()){Text("Start Upscaling")};OutlinedButton({vm.cancel()},Modifier.fillMaxWidth()){Text("Cancel Waiting")}}else{Spacer(Modifier.height(20.dp));Text("Select one or more JPEG, PNG, or WebP images to begin.")}}}}
@Composable fun Settings(nav:NavHostController,vm:AppViewModel){Scaffold(topBar={TopAppBar(title={Text("Upscale Settings")},navigationIcon={TextButton({nav.popBackStack()}){Text("Back")}})}){p->Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Default Resolution",style=MaterialTheme.typography.titleMedium);Target.values().forEach{t->Row{RadioButton(t==vm.target,{vm.target=t});Text(t.label,Modifier.padding(top=12.dp))}};Text("Output Format",style=MaterialTheme.typography.titleMedium);OutputFormat.values().forEach{f->Row{RadioButton(f==vm.format,{vm.format=f});Text(f.label,Modifier.padding(top=12.dp))}};Text("AI model: Real-ESRGAN General x4v3");Text("Processing is local to this device. No INTERNET permission is used.")}}}
@Composable fun History(nav:NavHostController,vm:AppViewModel){Scaffold(topBar={TopAppBar(title={Text("History")},navigationIcon={TextButton({nav.popBackStack()}){Text("Back")}})}){p->Column(Modifier.padding(p).padding(16.dp)){Text("Recent jobs are shown on the Home queue. Persistent history is written after completed MediaStore exports.")}}}
@Composable fun About(nav:NavHostController){Scaffold(topBar={TopAppBar(title={Text("About")},navigationIcon={TextButton({nav.popBackStack()}){Text("Back")}})}){p->Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("CN Upscaler",style=MaterialTheme.typography.headlineSmall);Text("Offline AI Image Super Resolution");Text("Model: realesr-general-x4v3, Real-ESRGAN, BSD-3-Clause. The model is bundled in assets and inference uses ONNX Runtime.");Text("Images are processed locally. The app does not upload images or require INTERNET permission.")}}}
