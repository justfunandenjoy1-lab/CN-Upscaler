package com.cn.upscaler.data
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.cn.upscaler.domain.*
class UpscaleWorker(ctx:Context,params:WorkerParameters):CoroutineWorker(ctx,params){
 companion object { const val CHANNEL="cn_upscaler_processing" }
 override suspend fun doWork():Result{
  val uri=inputData.getString("uri")?:return Result.failure();val target=runCatching{Target.valueOf(inputData.getString("target")?:Target.UHD_4K.name)}.getOrElse{return Result.failure()};val fmt=runCatching{OutputFormat.valueOf(inputData.getString("format")?:OutputFormat.JPEG.name)}.getOrElse{return Result.failure()}
  createChannel(); setForeground(foregroundInfo(0))
  return try{val out=ImageProcessor(applicationContext).process(android.net.Uri.parse(uri),target,fmt){setProgress(Data.Builder().putInt("progress",it).build())};Result.success(Data.Builder().putString("outputUri",out).build())}catch(t:Throwable){if(runAttemptCount<1)Result.retry() else Result.failure(Data.Builder().putString("error",t.message?:"Unknown processing error").build())}
 }
 private fun createChannel(){if(Build.VERSION.SDK_INT>=26){val nm=applicationContext.getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel(CHANNEL,"CN Upscaler processing",NotificationManager.IMPORTANCE_LOW))}}
 private fun foregroundInfo(progress:Int):ForegroundInfo{val n=NotificationCompat.Builder(applicationContext,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_upload).setContentTitle("CN Upscaler").setContentText("Processing image... $progress%").setOngoing(true).setProgress(100,progress,false).build();return if(Build.VERSION.SDK_INT>=29)ForegroundInfo(1001,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else ForegroundInfo(1001,n)}
}
