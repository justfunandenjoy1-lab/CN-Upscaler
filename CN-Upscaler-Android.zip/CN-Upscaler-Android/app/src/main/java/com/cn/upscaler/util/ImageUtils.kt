package com.cn.upscaler.util

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.cn.upscaler.domain.ImageInfo
import java.io.FileNotFoundException

object ImageUtils {
 fun inspect(context:Context,uri:Uri):ImageInfo {
   val resolver=context.contentResolver
   val size=resolver.openAssetFileDescriptor(uri,"r")?.use{it.length}.takeIf{it>=0}?:0L
   val opts=BitmapFactory.Options().apply{inJustDecodeBounds=true}
   resolver.openInputStream(uri).use{ BitmapFactory.decodeStream(it,null,opts) }
   if(opts.outWidth<=0||opts.outHeight<=0) throw IllegalArgumentException("Corrupted or unsupported image")
   val mime=opts.outMimeType ?: "image/unknown"
   if(mime !in listOf("image/jpeg","image/png","image/webp")) throw IllegalArgumentException("Unsupported image format")
   val orientation=try{resolver.openInputStream(uri)?.use{ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL)}?:ExifInterface.ORIENTATION_NORMAL}catch(_:Exception){ExifInterface.ORIENTATION_NORMAL}
   return ImageInfo(opts.outWidth,opts.outHeight,mime,size, mime=="image/png"||mime=="image/webp",orientation)
 }
 fun decode(context:Context,uri:Uri,maxPixels:Long=12_000_000L):Bitmap {
   val r=context.contentResolver; val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true}; r.openInputStream(uri).use{BitmapFactory.decodeStream(it,null,bounds)}
   if(bounds.outWidth<=0) throw FileNotFoundException("Unable to decode image")
   var sample=1; while(bounds.outWidth.toLong()/sample * (bounds.outHeight.toLong()/sample) > maxPixels) sample*=2
   val o=BitmapFactory.Options().apply{inSampleSize=sample; inPreferredConfig=Bitmap.Config.ARGB_8888}
   val b=r.openInputStream(uri).use{BitmapFactory.decodeStream(it,null,o)} ?: throw IllegalArgumentException("Decode failed")
   return orient(b, r.openInputStream(uri)?.use{ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION,ExifInterface.ORIENTATION_NORMAL)}?:1)
 }
 private fun orient(b:Bitmap,o:Int):Bitmap{ val m=Matrix(); when(o){6->m.postRotate(90f);3->m.postRotate(180f);8->m.postRotate(270f);2->m.preScale(-1f,1f);4->m.preScale(1f,-1f);5->{m.preScale(-1f,1f);m.postRotate(90f)};7->{m.preScale(-1f,1f);m.postRotate(270f)} }; return if(m.isIdentity)b else Bitmap.createBitmap(b,0,0,b.width,b.height,m,true).also{if(it!==b)b.recycle()} }
}
