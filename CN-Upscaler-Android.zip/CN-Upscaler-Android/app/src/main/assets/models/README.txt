CN Upscaler AI model slot

Required model:
realesr-general-x4v3.onnx

Provenance: Real-ESRGAN General x4v3, exported to ONNX.
License: BSD-3-Clause (Real-ESRGAN).
Expected scale: x4.

The build environment used to assemble this project did not have network access to retrieve the binary model, so the binary is intentionally NOT faked or replaced with a normal scaler.

Place the legally obtained ONNX model at this exact path before running AI processing:
app/src/main/assets/models/realesr-general-x4v3.onnx

The application will report a clear missing-model error rather than pretending AI processing is enabled.
