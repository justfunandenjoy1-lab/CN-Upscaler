package com.cn.upscaler.domain
import org.junit.Assert.*
import org.junit.Test
class ResolutionCalculatorTest{
 @Test fun landscape16x9(){val r=ResolutionCalculator.calculate(1920,1080,Target.UHD_4K);assertEquals(3840,r.width);assertEquals(2160,r.height)}
 @Test fun portraitPreservesRatio(){val r=ResolutionCalculator.calculate(1080,1920,Target.UHD_4K);assertEquals(2430,r.width);assertEquals(4320,r.height)}
 @Test fun squareFitsTarget(){val r=ResolutionCalculator.calculate(1000,1000,Target.UHD_2K);assertEquals(1440,r.width);assertEquals(1440,r.height)}
 @Test fun unusualRatio(){val r=ResolutionCalculator.calculate(4000,3000,Target.UHD_4K);assertEquals(2880,r.width);assertEquals(2160,r.height)}
 @Test fun filenameUniqueSuffix(){assertEquals("photo_CN_4K_AI_2.jpg",FileNameGenerator.generate("photo.jpg",Target.UHD_4K,OutputFormat.JPEG,2))}
}
