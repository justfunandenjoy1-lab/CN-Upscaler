package com.cn.upscaler.domain

import kotlin.math.roundToInt

data class Resolution(val width:Int,val height:Int,val scaleX:Float,val scaleY:Float){ val scale:Float=get()=minOf(scaleX,scaleY) }
object ResolutionCalculator {
 fun calculate(srcW:Int,srcH:Int,target:Target):Resolution {
   require(srcW>0&&srcH>0)
   val ratio=srcW.toDouble()/srcH
   val targetRatio=target.width.toDouble()/target.height
   val (w,h)=if(kotlin.math.abs(ratio-targetRatio)<0.001){target.width to target.height}else if(ratio>targetRatio){ target.width to (target.width/ratio).roundToInt() }else{ (target.height*ratio).roundToInt() to target.height }
   return Resolution(w,h,w.toFloat()/srcW,h.toFloat()/srcH)
 }
}
object FileNameGenerator { fun generate(original:String,target:Target,format:OutputFormat,index:Int=0):String { val base=original.substringBeforeLast('.',original).replace(Regex("[^A-Za-z0-9._-]"),"_"); val suffix=if(index==0)"" else "_$index"; return "${base}_CN_${target.label.substringBefore(' ')}_AI$suffix.${format.ext}" } }
