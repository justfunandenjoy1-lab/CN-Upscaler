# CN Upscaler

Offline-first Android image super-resolution application using Kotlin, Jetpack Compose, WorkManager and ONNX Runtime.

## Current implementation
- Application ID: `com.cn.upscaler`
- Kotlin + Jetpack Compose + Material 3
- Android Photo Picker, multi-select
- JPEG/PNG/WebP inspection and EXIF orientation correction
- Aspect-ratio-preserving 2K/4K/8K target calculator
- ONNX Runtime inference abstraction
- Real-ESRGAN General x4v3 inference engine with tiled processing and overlap blending
- WorkManager background jobs with foreground progress notification
- MediaStore output under `Pictures/CN Upscaler/<2K|4K|8K>/`
- Unit tests for resolution and file naming
- No INTERNET permission; images are intended to remain on-device

## AI model status
The binary `realesr-general-x4v3.onnx` is **not included in this ZIP** because the build environment could not retrieve the model binary. No fake model or ordinary image scaler is substituted.

Before AI processing can run, place the legally obtained model at:

`app/src/main/assets/models/realesr-general-x4v3.onnx`

The model is Real-ESRGAN General x4v3, x4, BSD-3-Clause. Real-ESRGAN's model zoo documents the General x4v3 model as a small general-image model; the upstream project documents BSD-3-Clause licensing for the project. The ONNX redistribution used by Open Pixels lists this exact ONNX artifact as BSD-3-Clause and provides its SHA-256: `0e121299bf9b23a764d3f9e2120d0d0727d5ac5032e03a46cb78d28bcc7c6872`.

## Build
Open the root folder in Android Studio. Use JDK 17 and an Android SDK with API 35 installed. The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21.

Run from a configured Android/Gradle environment:

`./gradlew test`

`./gradlew assembleDebug`

`./gradlew bundleRelease`

The supplied environment did not contain a usable Android SDK/Gradle installation, so build verification could not be honestly completed here.

## Architecture
`domain/` contains target and queue models and deterministic calculations. `data/` contains image processing, MediaStore export and WorkManager. `ml/` contains the model-specific inference abstraction. `ui/` contains the Compose UI and ViewModel.

## Tile processing
The Real-ESRGAN engine processes tiles sequentially. The default tile size is 192 pixels with 16-pixel overlap and blends overlapping output regions. Large images therefore do not require a single enormous input tensor.

## 2K/4K/8K
The target calculator preserves aspect ratio. For 16:9 input, 2K/4K/8K produce 2560x1440, 3840x2160 and 7680x4320. The AI model itself is x4; a final high-quality resize is used when the requested target does not exactly equal the x4 output.

## Privacy
There is no INTERNET permission and no analytics/tracking. Images are selected through Android's picker and written locally through MediaStore.

## Known limitations
1. The ONNX model binary must be supplied separately.
2. History UI is currently a lightweight queue/history placeholder rather than a full Room-backed persistent history browser.
3. Before/after comparison and advanced metadata editing are architectural follow-up work.
4. GPU/NNAPI registration is attempted through ONNX Runtime and falls back to the default provider, but device-specific acceleration cannot be verified without a physical/emulated Android runtime.
5. Build and runtime tests could not be executed in the supplied environment.
