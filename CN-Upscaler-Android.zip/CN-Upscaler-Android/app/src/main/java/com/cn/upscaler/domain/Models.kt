package com.cn.upscaler.domain

enum class Target(val label:String, val width:Int, val height:Int){ UHD_2K("2K UHD",2560,1440), UHD_4K("4K UHD",3840,2160), UHD_8K("8K UHD",7680,4320) }
enum class OutputFormat(val label:String, val mime:String, val ext:String){ JPEG("JPEG","image/jpeg","jpg"), PNG("PNG","image/png","png"), WEBP("WebP","image/webp","webp") }
enum class JobStatus { WAITING, PROCESSING, COMPLETED, FAILED, CANCELLED }
data class ImageInfo(val width:Int,val height:Int,val mime:String,val sizeBytes:Long,val hasAlpha:Boolean,val orientation:Int)
data class Job(val id:String,val uri:String,val name:String,val target:Target,val format:OutputFormat,val status:JobStatus=JobStatus.WAITING,val progress:Int=0,val error:String?=null,val outputUri:String?=null)
