package com.cn.upscaler.ui
import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.*
import com.cn.upscaler.data.UpscaleWorker
import com.cn.upscaler.domain.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID
class AppViewModel(app:Application):AndroidViewModel(app){
 private val wm=WorkManager.getInstance(app); private val _jobs=MutableStateFlow<List<Job>>(emptyList());val jobs:StateFlow<List<Job>>=_jobs
 var target=Target.UHD_4K; var format=OutputFormat.JPEG
 fun addUris(uris:List<Uri>){viewModelScope.launch{val new=uris.map{Job(UUID.randomUUID().toString(),it.toString(),it.lastPathSegment?:"image",target,format)};_jobs.value=_jobs.value+new}}
 fun process(){val snapshot=_jobs.value; if(snapshot.isEmpty())return; snapshot.filter{it.status==JobStatus.WAITING}.forEach{j->val req=OneTimeWorkRequestBuilder<UpscaleWorker>().setInputData(workDataOf("uri" to j.uri,"target" to j.target.name,"format" to j.format.name)).build();wm.enqueueUniqueWork("job_${j.id}",ExistingWorkPolicy.KEEP,req)}}
 fun cancel(){_jobs.value=_jobs.value.map{if(it.status==JobStatus.WAITING)it.copy(status=JobStatus.CANCELLED)else it}}
}
