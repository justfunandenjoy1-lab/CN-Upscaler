package com.cn.upscaler.data
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.cn.upscaler.domain.Job
import com.cn.upscaler.domain.JobStatus
class HistoryStore(ctx:Context){private val p=ctx.getSharedPreferences("history",0); fun add(j:Job){val a=JSONArray(p.getString("items","[]"));val o=JSONObject().apply{put("id",j.id);put("name",j.name);put("target",j.target.name);put("status",j.status.name);put("output",j.outputUri)};val n=JSONArray();n.put(o);for(i in 0 until minOf(a.length(),49))n.put(a.getJSONObject(i));p.edit().putString("items",n.toString()).apply()};fun clear(){p.edit().remove("items").apply()}}
